package com.example.springdatajpaex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringdatajpaexApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringdatajpaexApplication.class, args);
	}

}
